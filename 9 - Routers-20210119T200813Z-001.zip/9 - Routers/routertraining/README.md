# Important ! 

## Installation et lancement de l'application 
routertraining est une application de type Create React App toute prête.

Une fois le dossier routertraining téléchargé, ouvrir une console et lancer la commande 
`npm install` pour installer les modules. 

Pour faire tourner l'application, utiliser la commande `npm start`.

## Editer 

Pour commencer l'exercice, se placer sur le fichier App.js. 
