import './App.css';
import {BrowserRouter as Router, Link, Route, Switch, useParams, useHistory} from "react-router-dom";

function User() {
    const name = useParams().name; // useParams est un hook

    const history = useHistory(); // useHistory est un hook

    console.log(history);

    return (
        <div>
            Utilisateur {name}
            <p>
                <Link onClick={() => history.goBack()}>Retour</Link>
            </p>
        </div>
    )
}


function App() {
    return (
        <Router>
            <div className="App">
                <h2>Bonjour</h2>
                <div>
                    <Link to="/page1">Page 1</Link>
                    <Link to="/page2">Page 2</Link>
                    <Link to="/page3">Page 3</Link>
                    <Link to="/user/Gaëlle">User</Link>
                </div>

                <Switch>
                    <Route path={'/page1'}>
                        <div>Page 1</div>
                    </Route>
                    <Route path={'/page2'}>
                        <div>Page 2</div>
                    </Route>
                    <Route path={'/page3'}>
                        <div>Page 3</div>
                    </Route>
                    <Route path={'/user/:name'}>
                        <User/>
                    </Route>
                </Switch>

                <div>
                    Footer
                </div>

            </div>
        </Router>
    );
}

export default App;
